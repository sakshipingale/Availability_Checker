from tkinter import *
from PIL import Image,ImageTk

win=Tk()
win.title("Home Page")
win.geometry("1600x1600")

f1=('Microsoft Yahei UI Light',23,'bold')
path = Image.open("proj8.jpg")

resized = path.resize((1550,800),Image.ANTIALIAS)
new_pic = ImageTk.PhotoImage(resized)

img = Label(win,image=new_pic)
img.place(x=0,y=0)

def login():
    win.destroy()
    import login
def register():
    win.destroy()
    import register

l3=Label(win,text="Welcome to Availability Checker!",font=("Helvetica",26),fg='Black')
l3.place(x=530,y=280)
b1=Button(win,text="  Login  ",font=("Helvetica",26),bg='#19d4bc',command=login)
b1.place(x=550,y=370)
b2=Button(win,text="Register",font=("Helvetica",26),bg='#19d4bc',command=register)
b2.place(x=830,y=370)

# win.resizable(0,0)
win.mainloop()

