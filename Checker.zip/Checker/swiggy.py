import tkinter as tk
from tkinter import *
from PIL import Image,ImageTk
import webbrowser
root = tk.Tk()
root.title("")

def back():
    root.destroy()
    import avail1

path = Image.open("proj8.jpg")
resized = path.resize((1530,800),Image.ANTIALIAS)
new_pic = ImageTk.PhotoImage(resized)
img = Label(root,image=new_pic)
img.place(x=0,y=0)
def callback(url):
    webbrowser.open_new_tab(url)

link = Label(root,text="https://www.swiggy.com",font=('Helvetica',20),fg="blue",cursor="hand2")
link.pack()
link.bind("<Button-1>",lambda e:callback("https://www.swiggy.com"))
link.place(x=630,y=350)
b1=Button(root,text=" Back ",font=("Courier",17,"bold"),bg='#87ceeb',command=back)
b1.place(x=720,y=460)

root.geometry("1600x1600")
root.mainloop()
