import tkinter as tk
from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector
import webbrowser

root = tk.Tk()
root.title("Checker")

path = Image.open("proj9.jpg")
resized = path.resize((1530,800),Image.ANTIALIAS)
new_pic = ImageTk.PhotoImage(resized)
img = Label(root,image=new_pic)
img.place(x=0,y=0)

f1=('Microsoft Yahei UI Light',15)

frame1 =Frame(root,bg="white",width=440,height=450)
frame1.pack(pady=120,padx=170)
frame1.place(x=550,y=200)
def newcafe():
    root.destroy()
    import cafe
    

def home():
    root.destroy()
    import home

def linkz():
    root.destroy()
    import zomato

def links():
    root.destroy()
    import swiggy

def linko():
    root.destroy()
    import ola

def linku():
    root.destroy()
    import uber


def demo():
    s1=t1.get();
    if s1=="":
        messagebox.showinfo("Warning.","Please Enter Cityname")
        return

    mydb = mysql.connector.connect(
    user="root",
    password="",
    host="localhost",
    port="3307",
    database="my_proj"
    )
    mycur = mydb.cursor()    
    var2 = "select city from district_table where city = '"+s1+"'"
    mycur.execute(var2)
    mycur.fetchall()
    print(mycur)
    if mycur.rowcount<=0:
        messagebox.showinfo("Warning.","Not Found")
        return

def zomato():
    s1=t1.get();
    if s1=="":
        messagebox.showinfo("Warning.","Please Enter Cityname")
        return
    mydb = mysql.connector.connect(
    user="root",
    password="",
    host="localhost",
    port="3307",
    database="my_proj"
    )
    mycur = mydb.cursor() 
    print("True")   
    mycur.execute("select zomato from zomato where city In (select city from district_table where city ='"+s1+"')")
    print(mycur)
    mydata = mycur.fetchone()
    print(mydata)  
    if mydata[0]=='Available':
        messagebox.showinfo("","This service is available in '"+s1+"'")
        linkz()

    else:
        messagebox.showinfo("","This service is currently unavailable in '"+s1+"'")
        newcafe()


      
def swiggy():
    s1=t1.get();
    if s1=="":
        messagebox.showinfo("Warning.","Please Enter Cityname")
        return
    mydb = mysql.connector.connect(
    user="root",
    password="",
    host="localhost",
    port="3307",
    database="my_proj"
    )
    mycur = mydb.cursor() 
    print("True")
    mycur.execute("select swiggy from swiggy where city In (select city from district_table where city ='"+s1+"')")
    print(mycur)
    mydata = mycur.fetchone()
    print(mydata)
    if mydata[0]=='Available':
        messagebox.showinfo("","This service is available in '"+s1+"'")
        links()
    else:
        messagebox.showinfo("","This service is currently unavailable in '"+s1+"'")
        newcafe()

    
# def cafe():
#     s1=t1.get();
#     if s1=="":
#         messagebox.showinfo("Warning.","Please Enter Cityname")
#         return

#     mydb = mysql.connector.connect(
#     user="root",
#     password="",
#     host="localhost",
#     port="3307",
#     database="my_proj"
#     )
#     print("True")
#     mycur = mydb.cursor() 
    
#     mycur.execute("select Cafe from cafe_avail where City In (select city from district_table where city ='"+s1+"')")
#     print(mycur)
#     mydata = mycur.fetchone()
#     print(mydata)
#     if mydata[0]=='Available':
#         messagebox.showinfo("","This service is available in '"+s1+"'")
#         newcafe()
        
#     else:
#         messagebox.showinfo("","This service is currently unavailable in '"+s1+"'")


    # for item in mydata: 
    #     print(item)
    # if mydata[0]=='Available':
    #     messagebox.showinfo("","This service is available in '"+s1+"'")
    # else:
    #     messagebox.showinfo("","This service is currently unavailable in '"+s1+"'")

 

def ola():
    s1=t1.get();
    if s1=="":
        messagebox.showinfo("Warning.","Please Enter Cityname")
        return
    mydb = mysql.connector.connect(
    user="root",
    password="",
    host="localhost",
    port="3307",
    database="my_proj"
    )
    mycur = mydb.cursor() 
    print("True")  
    mycur.execute("select ola from ola where city In (select city from district_table where city ='"+s1+"')")
    print(mycur)
    mydata = mycur.fetchone()
    print(mydata)
    if mydata[0]=='Available':
        messagebox.showinfo("Warning.","This service is available in '"+s1+"'")
        linko()
    else:
        messagebox.showinfo("Warning.","This service is currently unavailable in '"+s1+"'")

def uber():
    s1=t1.get();
    if s1=="":
        messagebox.showinfo("Warning.","Please Enter Cityname")
        return
    mydb = mysql.connector.connect(
    user="root",
    password="",
    host="localhost",
    port="3307",
    database="my_proj"
    )
    mycur = mydb.cursor() 
    print("True")   
    mycur.execute("select uber from uber where city In (select city from district_table where city ='"+s1+"')")
    print(mycur)
    mydata = mycur.fetchone()
    print(mydata)  
    if mydata[0]=='Available':
        messagebox.showinfo("","This service is available in '"+s1+"'")
        linku()
    else:
        messagebox.showinfo("","This service is currently unavailable in '"+s1+"'")


def Citybuses():
    s1=t1.get();
    if s1=="":
        messagebox.showinfo("Warning.","Please Enter Cityname")
        return
    mydb = mysql.connector.connect(
    user="root",
    password="",
    host="localhost",
    port="3307",
    database="my_proj"
    )
    mycur = mydb.cursor() 
    print("True")   
    mycur.execute("select city_buses from city_buses where city In (select city from district_table where city ='"+s1+"')")
    print(mycur)
    mydata = mycur.fetchone()
    print(mydata)  
    if mydata[0]=='Available':
        messagebox.showinfo("","This service is available in '"+s1+"'")
    else:
        messagebox.showinfo("","This service is currently unavailable in '"+s1+"'")

def airport():
    s1=t1.get();
    if s1=="":
        messagebox.showinfo("Warning.","Please Enter Cityname")
        return
    mydb = mysql.connector.connect(
    user="root",
    password="",
    host="localhost",
    port="3307",
    database="my_proj"
    )
    mycur = mydb.cursor() 
    print("True")   
    mycur.execute("select airport from airport where city In (select city from district_table where city ='"+s1+"')")
    print(mycur)
    mydata = mycur.fetchone()
    print(mydata)  
    if mydata[0]=='Available':
        messagebox.showinfo("","This service is available in '"+s1+"'")
    else:
        messagebox.showinfo("","This service is currently unavailable in '"+s1+"'")
        
def railway_station():
    s1=t1.get();
    if s1=="":
        messagebox.showinfo("Warning.","Please Enter Cityname")
        return
    mydb = mysql.connector.connect(
    user="root",
    password="",
    host="localhost",
    port="3307",
    database="my_proj"
    )
    mycur = mydb.cursor() 
    print("True")   
    mycur.execute("select station from railway_station where city In (select city from district_table where city ='"+s1+"')")
    print(mycur)
    mydata = mycur.fetchone()
    print(mydata)  
    if mydata[0]=='Available':
        messagebox.showinfo("","This service is available in '"+s1+"'")
    else:
        messagebox.showinfo("","This service is currently unavailable in '"+s1+"'")


l1=Label(root,text="Search Your City",font=("Helvetica"),fg='black')
l1.place(x=690,y=250)
t1=Entry(root,bd=2,font=f1)
t1.place(x=640,y=310)
b1=Button(root,text="🔎",font=f1,bg='#D2D2D2',command=demo)
b1.place(x=870,y=300)

var = tk.StringVar(value="Categories")
menubutton = tk.Menubutton(root, textvariable=var, indicatoron=True,
                        borderwidth=1.5, relief="raised", width=20,justify=CENTER,highlightcolor="green")
main_menu = tk.Menu(menubutton, tearoff=False)
menubutton.configure(menu=main_menu)
# menubutton.pack(padx=150,pady=150)
# menubutton.place(x=0,y=0)
   
sublist1 = tk.Menu(main_menu,tearoff=False)
main_menu.add_cascade(label="Food",menu=sublist1)
sublist1.add_command(label="Zomato",command=zomato)
sublist1.add_command(label="Swiggy",command=swiggy)
# sublist1.add_command(label="Cafe",command=cafe)
# sublist1.add_command(label="Restaurants")

sublist2 = tk.Menu(main_menu,tearoff=False)
main_menu.add_cascade(label="Travel",menu=sublist2)
sublist2.add_command(label="Ola",command=ola)
sublist2.add_command(label="Uber",command=uber)
sublist2.add_command(label="City Buses",command=Citybuses)
sublist2.add_command(label="Airport",command=airport)
sublist2.add_command(label="Railway Station",command=railway_station)
        
# sublist3 = tk.Menu(main_menu,tearoff=False)
# main_menu.add_cascade(label="Entertainment",menu=sublist3)
# sublist3.add_command(label="Movie theater")
# sublist3.add_command(label="Famous Places")

# sublist4 = tk.Menu(main_menu,tearoff=False)
# main_menu.add_cascade(label="Shopping",menu=sublist4)
# sublist4.add_command(label="Dmart")
# sublist4.add_command(label="Local market")
# sublist4.add_command(label="Supershop")
        
# sublist5 = tk.Menu(main_menu,tearoff=False)
# main_menu.add_cascade(label="Residency",menu=sublist5)
# sublist5.add_command(label="Residential Hotels")
# sublist5.add_command(label="Hostels")

b1=Button(root,text=" Back ",font=("Courier",17,"bold"),bg='#87ceeb',command=home)
b1.place(x=720,y=570)

menubutton.pack(side="top", padx=30, pady=390)

root.geometry("1600x1600")
root.mainloop()
