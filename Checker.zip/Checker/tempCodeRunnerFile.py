
path = Image.open("proj9.jpg")
resized = path.resize((1530,800),Image.ANTIALIAS)
new_pic = ImageTk.PhotoImage(resized)
img = Label(root,image=new_pic)
img.place(x=0,y=0)
