import tkinter as tk
from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector
import webbrowser

root = tk.Tk()
root.title("")
f1=('Microsoft Yahei UI Light',15)


path = Image.open("proj13.jpg")
resized = path.resize((1530,800),Image.ANTIALIAS)
new_pic = ImageTk.PhotoImage(resized)
img = Label(root,image=new_pic)
img.place(x=0,y=0)


def new():
    s1=t1.get();
    if s1=="":
        messagebox.showinfo("Warning.","Please Enter Cityname")
        return 
    mydb = mysql.connector.connect(
    user="root",
    password="",
    host="localhost",
    port="3307",
    database="my_proj"
    )
    print("True")
    mycur = mydb.cursor() 

    mycur.execute("select cafe_name,cafe_add from cafe where City In (select city from district_table where city ='"+s1+"') limit 0,5")

    mydata = mycur.fetchall()
    print(mydata)
    
    i=0
    for stud in mydata:
        for j in range(len(stud)):
            e= Entry(root,width=50,fg='Black')
            e.grid(row=i,column=j)
            e.insert(END,stud[j])     
        i=i+1

   
l1=Label(root,text="You Can search local restaurants and cafe's here by simply searching your City",font=("Helvetica"),fg='black')
l1.place(x=450,y=250)
t1=Entry(root,bd=2,font=f1)
t1.place(x=640,y=310)
b1=Button(root,text="Search",font=f1,bg='#D2D2D2',command=new)
b1.place(x=710,y=380)



root.geometry("1600x1600")
root.mainloop()



    
    #     mydata[i]= list(mydata[i])

    # else:
    #     messagebox.showinfo("","This service is currently unavailable in '"+s1+"'")
    
    # cafe_name = ""
    # cafe_add = ""
    # for i in range(len(mydata)):
    #     mydata[i]= list(mydata[i])
    # for i in range(len(mydata)):
    #     cafe_name = cafe_name+ mydata[i][0]+"\n"
    #     cafe_add = cafe_add+"\n"+  mydata[i][1]
    # print(cafe_name)
    # print(cafe_add)

    # l1=Label(root,text=cafe_name,font=("Helvetica"),fg='black')
    # l1.place(x=690,y=20)

    # E1.config(text=cafe_name,height=2,width=10)
    # E1.delete(0,END)
    # E1.insert(0,cafe_name)
    # E2.config(text=cafe_add,height=4,width=14)   

# new(s1)    
# l1=Label(root,text="Veda Rushikesh",font=("Helvetica"),fg='black')
# l1.place(x=690,y=20)
# E1=Entry(root,font=("arial",12,"bold"))
# E1.place(x=100,y=100)
# E2=Entry(root,font=("arial",14,"bold"))
# E2.place(x=200,y=200)



# b1=Button(root,text=" ",font=("Courier",17,"bold"),bg='#87ceeb',command=home)
# b1.place(x=720,y=570)


    



# select cafe_name,cafe_add from cafe where city='"+s1+"'