from tkinter import *
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector
win=Tk()
win.title("Registration Page")
f1=('Microsoft Yahei UI Light',15)

path = Image.open("proj9.jpg")
resized = path.resize((1530,800),Image.ANTIALIAS)
new_pic = ImageTk.PhotoImage(resized)
img = Label(win,image=new_pic)
img.place(x=0,y=0)
frame1 =Frame(win,bg="white",width=450,height=550)
frame1.pack(pady=150,padx=100)

def clr():
    t1.delete(0,END)
    t2.delete(0,END)
    t3.delete(0,END)

def Register():
    win.destroy()
    import register

def back():
    win.destroy()
    import home

def register():
    s1=t1.get();
    s2=t2.get();
    s3=t3.get();
    
    if s1=="":
        messagebox.showinfo("Warning.","Please Enter Username")
        return
    if s2=="":
        messagebox.showinfo("Warning.","Please Enter Email")
        return
    if s3=="":
        messagebox.showinfo("Warning.","Please Enter Password")
        return
    mydb = mysql.connector.connect(
        user="root",
        password="",
        host="localhost",
        port="3307",
        database="my_proj"
    )
    mycur = mydb.cursor()
    mycur.execute(
        "insert into register values('"+s1+"','"+s2+"',"+s3+")"
    )
    mydb.commit()
    messagebox.showinfo("Confirm.","registred  successfully")
    clr()

heading = Label(win, text="Register", font=("Helvetica",26,"bold"), bg='white', fg='black')
heading.place(x=710, y=200)

l1=Label(win,text="Username",font=("Helvetica"),fg='black')
l1.place(x=560,y=300)
t1=Entry(win,bd=2,font=f1)
t1.place(x=750,y=300)

l2=Label(win,text="Email Id",font=("Helvetica"),fg='black')
l2.place(x=560,y=370)
t2=Entry(win,bd=2,font=f1)
t2.place(x=750,y=370)

l3=Label(win,text="Password",font=("Helvetica"),fg='black')
l3.place(x=560,y=440)
t3=Entry(win,bd=2,font=f1)
t3.place(x=750,y=440)

b1=Button(win,text="Register",font=("Courier",18,"bold"),bg='medium orchid',command=register)
b1.place(x=800,y=550)
b2=Button(win,text=" Back ",font=("Courier",17,"bold"),bg='medium orchid',command=back)
b2.place(x=615,y=550)


win.geometry("1600x1600")
win.mainloop()


